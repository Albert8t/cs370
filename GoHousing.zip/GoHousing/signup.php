<div style="background-color: #f4ecf7
;width:100%;height:325%;">

    <center>





            <?php






            $user['email']=$_POST['email'];
            $user['pass']=$_POST['pass'];
            print $user['email'];
            print $user['pass'];



            ?>


    </center>


</div>
