<?php
session_start();

    if (isset($_POST["survey"])){
            if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
               header('Location: ./survey.html/ );
            } else {
                echo "Please log in first to see this page.";
            }
        }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Roommate searching page</title>
</head>
<body>
    <input type="submit" id="survey" name="Finish Survey" value="survey" /></body>

</html>

